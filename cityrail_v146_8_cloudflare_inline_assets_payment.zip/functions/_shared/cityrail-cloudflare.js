// CityRail Cloudflare Pages Functions shared utilities.
// Secrets must be configured in Cloudflare Pages environment variables, never in frontend JS.

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json;charset=utf-8',
      'cache-control': 'no-store',
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'GET,POST,OPTIONS',
      'access-control-allow-headers': 'Content-Type',
    },
  });
}

export function text(body, status = 200) {
  return new Response(String(body), {
    status,
    headers: {
      'content-type': 'text/plain;charset=utf-8',
      'cache-control': 'no-store',
      'access-control-allow-origin': '*',
    },
  });
}

export function handleOptions() {
  return new Response(null, {
    status: 204,
    headers: {
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'GET,POST,OPTIONS',
      'access-control-allow-headers': 'Content-Type',
    },
  });
}

export async function parseBody(request) {
  const type = String(request.headers.get('content-type') || '').toLowerCase();
  if (type.includes('application/json')) {
    try { return await request.json(); } catch { return {}; }
  }
  if (type.includes('application/x-www-form-urlencoded') || type.includes('multipart/form-data')) {
    try { return Object.fromEntries((await request.formData()).entries()); } catch {}
  }
  const raw = await request.text().catch(() => '');
  if (!raw) return {};
  try { return JSON.parse(raw); } catch {}
  try {
    const params = new URLSearchParams(raw);
    const obj = Object.fromEntries(params.entries());
    return Object.keys(obj).length ? obj : { raw };
  } catch {
    return { raw };
  }
}

export function requireKV(env) {
  if (!env || !env.CITYRAIL_KV) {
    throw new Error('CITYRAIL_KV binding is missing. Bind a Cloudflare KV namespace named CITYRAIL_KV.');
  }
  return env.CITYRAIL_KV;
}

export function paymentConfig(env) {
  return {
    appid: env.XHP_APPID || '201906180967',
    secret: env.XHP_APPSECRET || '',
    gateway: env.XHP_GATEWAY || 'https://api.xunhupay.com/payment/do.html',
    amount: String(env.CITYRAIL_PRICE || '9.98'),
    title: env.CITYRAIL_PRODUCT_TITLE || 'CityRail都市城轨完整版',
    publicBaseUrl: String(env.PUBLIC_BASE_URL || '').replace(/\/$/, ''),
  };
}

export function publicBaseUrl(request, env) {
  const cfg = paymentConfig(env);
  if (cfg.publicBaseUrl) return cfg.publicBaseUrl;
  const url = new URL(request.url);
  return `${url.protocol}//${url.host}`;
}

function randomBytes(size) {
  const arr = new Uint8Array(size);
  crypto.getRandomValues(arr);
  return arr;
}

function bytesToHex(bytes) {
  return [...bytes].map(b => b.toString(16).padStart(2, '0')).join('');
}

export function makeTradeId() {
  return ('CR' + Date.now().toString(36) + bytesToHex(randomBytes(4))).slice(0, 32);
}

export function makeNonce(size = 8) {
  return bytesToHex(randomBytes(size));
}

export function constantTimeEqual(a, b) {
  a = String(a || '');
  b = String(b || '');
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}

// Minimal MD5 implementation for Xunhupay signing. Cloudflare WebCrypto does not expose MD5.
function md5cycle(x, k) {
  let [a, b, c, d] = x;
  a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586); c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
  a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426); c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
  a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417); c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
  a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101); c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
  a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632); c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
  a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083); c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
  a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690); c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
  a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784); c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
  a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463); c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
  a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353); c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
  a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222); c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
  a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835); c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
  a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415); c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
  a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606); c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
  a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744); c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
  a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379); c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
  x[0] = add32(a, x[0]); x[1] = add32(b, x[1]); x[2] = add32(c, x[2]); x[3] = add32(d, x[3]);
}
function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
function md5blk(s) { const md5blks = []; for (let i = 0; i < 64; i += 4) md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) + (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24); return md5blks; }
function md5blkArray(a) { const md5blks = []; for (let i = 0; i < 64; i += 4) md5blks[i >> 2] = a[i] + (a[i + 1] << 8) + (a[i + 2] << 16) + (a[i + 3] << 24); return md5blks; }
function md51(s) { return md51Array(new TextEncoder().encode(s)); }
function md51Array(a) { let n = a.length, state = [1732584193, -271733879, -1732584194, 271733878], i; for (i = 64; i <= n; i += 64) md5cycle(state, md5blkArray(a.subarray(i - 64, i))); const tail = new Uint8Array(64); tail.set(a.subarray(i - 64)); tail[n % 64] = 128; if (n % 64 > 55) { md5cycle(state, md5blkArray(tail)); tail.fill(0); } const bitLen = n * 8; for (let j = 0; j < 8; j++) tail[56 + j] = Math.floor(bitLen / Math.pow(256, j)) & 255; md5cycle(state, md5blkArray(tail)); return state; }
function rhex(n) { let s = '', j; for (j = 0; j < 4; j++) s += ((n >> (j * 8 + 4)) & 0x0F).toString(16) + ((n >> (j * 8)) & 0x0F).toString(16); return s; }
function hex(x) { return x.map(rhex).join(''); }
function add32(a, b) { return (a + b) & 0xFFFFFFFF; }
export function md5(str) { return hex(md51(String(str))).toLowerCase(); }

export function xhpHash(params, secret) {
  const pairs = Object.keys(params || {})
    .filter(k => k !== 'hash' && params[k] !== undefined && params[k] !== null && String(params[k]) !== '')
    .sort()
    .map(k => `${k}=${params[k]}`);
  return md5(pairs.join('&') + String(secret || ''));
}

export function verifyXhpHash(params, secret) {
  if (!params || !params.hash || !secret) return false;
  return constantTimeEqual(xhpHash(params, secret), String(params.hash).toLowerCase());
}

export function orderKey(id) { return `order:${id}`; }
export function pendingUserKey(username) { return `pending-user:${username}`; }
export function userKey(username) { return `user:${username}`; }

export function normalizeUsername(username) {
  return String(username || '').trim();
}

export function validateCredentials(username, password) {
  const u = normalizeUsername(username);
  const p = String(password || '');
  if (!u || !p) return '用户名和密码不能为空';
  if (u.length < 3 || u.length > 15) return '用户名长度需在 3-15 个字符之间';
  if (p.length < 3 || p.length > 15) return '密码长度需在 3-15 个字符之间';
  return '';
}

async function derivePassword(password, saltHex, iterations = 120000) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const salt = new Uint8Array(saltHex.match(/.{1,2}/g).map(x => parseInt(x, 16)));
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, keyMaterial, 256);
  return bytesToHex(new Uint8Array(bits));
}

export async function hashPassword(password) {
  const salt = bytesToHex(randomBytes(16));
  const iterations = 120000;
  const hash = await derivePassword(password, salt, iterations);
  return `pbkdf2-sha256:${iterations}:${salt}:${hash}`;
}

export async function verifyPassword(password, stored) {
  const parts = String(stored || '').split(':');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2-sha256') return false;
  const iterations = Number(parts[1]) || 120000;
  const salt = parts[2];
  const expected = parts[3];
  const actual = await derivePassword(password, salt, iterations);
  return constantTimeEqual(actual, expected);
}

export function maskOrder(order) {
  if (!order) return null;
  return {
    trade_order_id: order.trade_order_id,
    status: order.status,
    amount: order.amount,
    title: order.title,
    createdAt: order.createdAt,
    paidAt: order.paidAt || null,
    username: order.username,
  };
}
